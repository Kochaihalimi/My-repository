package Immutable_objects;
//the following Example is of immutable objects.
public class Example {
	private final String s;
	Example(final String s){
		this.s=s;
	}
	
 public final String getname() {
		return s;
	}

	public static void main(String[] args) {
		Example e =new Example("kochai");
	System.out.println(e.getname());
	Example e1=new Example("Halimi");
	System.out.println(e1.getname());
	
	


		


	}
	

}



