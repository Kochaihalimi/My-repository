package pack1;
import java.util.LinkedList;
import java.util.ListIterator;


public class A {

	public static void main(String[] args) {
	LinkedList<book> list=new LinkedList<book>();
	
	list.add(new book(01,"c++","kochai"));
	list.add(new book(02,"c#","farhad"));
	list.add(new book(03,"python","sadip"));
	list.add(new book(04,"java","farid"));
	
	System.out.println("data using for loop ");
	for(book obj: list) {
		System.out.println(obj.id+" : "+obj.getAuthorname()+","+obj.getAuthorname());
	}
	
	ListIterator<book> iter2=list.listIterator();
	while(iter2.hasNext()) {
		book o=iter2.next();
		if(o.getAuthorname()=="farid") {
			iter2.remove();
		}
		
	}
	System.out.println("-----------------------------------------------------------------");
	System.out.println("data after iterator");
	for(book obj: list) {
		System.out.println(obj.id+" : "+obj.getAuthorname()+","+obj.getAuthorname());
	}
	
	}

}
