package arraylist;

import java.util.ArrayList;

public class A {

	public static void main(String[] args) {
		ArrayList mlist=new ArrayList();
		mlist.add("kochai");
		mlist.add(123);
		mlist.add(12.34);
		mlist.add('A');
		
		System.out.println(mlist);
	}

}
