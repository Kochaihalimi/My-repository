package Context_switching;

public class MyTread extends Thread{
		
			public void run() {
			for(int i=0; i<=100; i++) {
				System.out.print("a");
			}
				
		}

	public static void main(String[] args) {
		
		MyTread m=new MyTread();
		m.start();
	
		for(int i=0; i<=100; i++) {
			System.out.print(i+" ");
	}
	}

}
