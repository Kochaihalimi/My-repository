package Mutable_object;
// mutable object Example

public class Example{
	
	private String s;
	Example(String s){
		this.s=s;
		
	}
	public void setname(String username) {
		this.s=username;
	}
	
	public String getname() {
		return s;
	}

	public static void main(String[] args) {
		Example e =new Example("kochai");
	System.out.println(e.getname());
		e.setname("Halimi");
	System.out.println(e.getname());
		

	}
	

}
