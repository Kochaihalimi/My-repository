package pack;
import java.util.Stack;

public class Stacks {

	public static void main(String[] args) {
		Stack<String> Slist = new Stack<String>();
		Slist.push("kochai");
		Slist.push("khalid");
		Slist.push("shahamat");
		Slist.push("sardar");
		Slist.push("gulab");
		
		System.out.println(Slist);
		Slist.peek();
		System.out.println(Slist);
		Slist.pop();
		System.out.println(""+Slist);
		
	}

}
