package pack;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;

public class test1 {

	public static void main(String[] args) {
		HashSet<String> My_hash = new HashSet<String>();
			My_hash.add("farhad");
			My_hash.add("kochai");
			My_hash.add("farid");
			My_hash.add("sadiq");
			My_hash.add("shrif");
			
		System.out.println("my hash set=="+My_hash);
		
		 //both not support duplicate value
	     //linked hash set is order data showing
		
		LinkedHashSet<String> mhash2 = new LinkedHashSet<String>();
		
		My_hash.add("farhad");
		My_hash.add("kochai");
		My_hash.add("farid");
		My_hash.add("sadiq");
		My_hash.add("shrif");
		System.out.println("my hash set2=="+mhash2);
		
		
		

	}

}
