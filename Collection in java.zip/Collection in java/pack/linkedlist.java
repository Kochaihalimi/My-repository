package pack;

import java.util.LinkedList;

public class linkedlist {

	public static void main(String[] args) {
		LinkedList<String> Mylist = new LinkedList<String>();
		Mylist.add("kochia");
		Mylist.add("khalid");
		Mylist.add("ahmad");
		Mylist.add("zhain");
		Mylist.add("khaibar");
		Mylist.add("Hlimai");
		
		System.out.println(Mylist);
		Mylist.addFirst("kochai");
		Mylist.addLast("sharif");
		System.out.println(Mylist);
		Mylist.add(2, "zahid");
		System.out.println(Mylist);
		Mylist.remove();
		System.out.println("remove the first elements==>:-"+Mylist.remove());
		Mylist.remove(3);
   System.out.println("specific elements=>:"+Mylist.remove());
   Mylist.removeLast();
              System.out.println("remove the last element=>:"+Mylist.removeLast());
	}

}
