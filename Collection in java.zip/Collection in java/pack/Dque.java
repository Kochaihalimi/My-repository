package pack;

import java.util.Deque;
import java.util.ArrayDeque;

public class Dque {

	public static void main(String[] args) {
		
		Deque<String> DeQ = new ArrayDeque<String>();
		 DeQ.add("kochai");
		 DeQ.add("kamal");
		 DeQ.add("ahmad");
		 DeQ.add("sharif");
		 DeQ.add("hamid");
		
		for(String str: DeQ) {
			System.out.println(str);
		}
		

	}

}
