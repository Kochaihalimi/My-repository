package pack;

import java.util.TreeSet;

public class treeset {

	public static void main(String[] args) {
	
		TreeSet<String> TS =new TreeSet<String>();
		TS.add("kochai");
		TS.add("sanam");
		TS.add("khalid");
		TS.add("shah jahan");
		TS.add("khalil");
		
		System.out.println(TS.toString());
		TreeSet<Integer> TS1 =new TreeSet<Integer>();
		TS1.add(12);
		TS1.add(33);
		TS1.add(23);
		TS1.add(5);
		TS1.add(23);
		TS1.add(55);
		System.out.println(TS1);
		
		
		

	}

}
