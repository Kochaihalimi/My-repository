package pack;
import java.util.Vector;

public class vector {

	public static void main(String[] args) {
		Vector My_vector =new Vector();
		    My_vector.add("kochai");
		    My_vector.add("khan");
		    My_vector.add("khalil");
		    My_vector.add("Ahmad");
		    My_vector.add("Samsor");
		    My_vector.add("Zahid");
		 
		    System.out.println(My_vector);

	}

}
