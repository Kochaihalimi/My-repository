package pack;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;

public class arraylist {
	public static void main(String args[]) {
		HashSet<String> mset =new HashSet<String>();
		mset.add("farhad zahin");
		mset.add("farid");
		mset.add("computer");
		mset.add("ali");
		mset.add("wahid");
		
		
		System.out.println("this is hash set=="+mset.toString());
		
		LinkedHashSet<String> lhset = new LinkedHashSet<String>();
		lhset.add("farhad zahin");
		lhset.add("farid");
		lhset.add("computer");
		lhset.add("ali");
		lhset.add("wahid");
		
		
		System.out.println("Linked hashset=="+lhset.toString());
			
		
		
		
	}

}
