package Set;
import java.util.*;

public class SetExample {

	public static void main(String[] args) {
		Set<String> data=new LinkedHashSet<String>();
		System.out.println("is data is empty "+data.isEmpty());
		data.add("kochai");
		data.add("Halimi");
		data.add("Farhad");
		data.add("Farhad");
		
	// we can to add a set to another set in tow ways:

//		Set<String> k=new HashSet<String>(data); first way
		Set<String> k=new HashSet<String>(); 
		k.addAll(data);  //second way
		k.add("sharif");
		k.add("sadiq");
		System.out.println(k);
		
		
	

	}

}
